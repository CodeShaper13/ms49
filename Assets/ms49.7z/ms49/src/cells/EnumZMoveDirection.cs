﻿public enum EnumZMoveDirection {

    Neither = 0,
    Up = 1,
    Down = 2,
    Both = 3,
}
