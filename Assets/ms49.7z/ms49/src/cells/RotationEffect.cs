﻿public enum RotationEffect {

    Nothing = 0,
    MirrorX = 1,
    MirrorY = 2,
    Rotate90 = 3,
    Rotate180 = 4,
    Rotate270 = 5,
}
