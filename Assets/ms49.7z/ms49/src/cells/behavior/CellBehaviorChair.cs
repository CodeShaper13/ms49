﻿using UnityEngine;

public class CellBehaviorChair : CellBehavior {

}
