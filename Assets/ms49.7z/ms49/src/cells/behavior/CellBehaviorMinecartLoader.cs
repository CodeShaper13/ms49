﻿using UnityEngine;
using fNbt;

public class CellBehaviorMinecartLoader : CellBehaviorContainer, IMinecartInteractor {

    [SerializeField]
    private float _itemTransferSpeed = 1f;
    [SerializeField]
    private bool _isUnloader = false;

    private float transferTimer;

    public EntityMinecart minecart { get; set; }

    public bool isUnloader => this._isUnloader;

    public override void onUpdate() {
        base.onUpdate();

        this.transferTimer -= Time.deltaTime;

        if(this.minecart != null) {
            if(this.isUnloader) {
                // Pull items from the cart
                if(this.minecart.inventory.IsEmpty || this.inventory.IsFull) {
                    // Cart is empty, send it off
                    this.releaseCart();
                    return;
                }

                if(this.transferTimer <= 0) {
                    this.Deposit(this.minecart.inventory.PullItem());
                    this.transferTimer = this._itemTransferSpeed;
                }

            } else {
                // Add items to the cart.
                if(this.minecart.inventory.IsFull || this.inventory.IsEmpty) {
                    // Cart is full, send it off.
                    this.releaseCart();
                    return;
                }

                if(this.transferTimer <= 0) {
                    this.minecart.inventory.AddItem(this.PullItem());
                    this.transferTimer = this._itemTransferSpeed;
                }
            }
        }
    }

    public override void onDestroy() {
        base.onDestroy();

        if(this.minecart != null) {
            this.releaseCart();
        }
    }

    public override void ReadFromNbt(NbtCompound tag) {
        base.ReadFromNbt(tag);

        this.transferTimer = tag.getFloat("transferTimer");
    }

    public override void WriteToNbt(NbtCompound tag) {
        base.WriteToNbt(tag);

        tag.setTag("transferTimer", this.transferTimer);
    }

    private void releaseCart() {
        this.minecart.release();
        this.minecart = null;
    }

    public bool ShouldCartInteract(EntityMinecart cart) {
        if(cart.position != this.pos + this.rotation) {
            return false; // Minecart not in front of Loader.
        }

        if(this.isUnloader) {
            return !this.IsFull && !cart.inventory.IsEmpty;
        }
        else {
            return !this.IsEmpty && !cart.inventory.IsFull;
        }
    }

    public Vector3 GetCartStopPoint() {
        return this.center + this.rotation.vectorF;
    }
}
