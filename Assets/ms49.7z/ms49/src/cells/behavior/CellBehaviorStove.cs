﻿using UnityEngine;
using System.Collections;

public class CellBehaviorStove : CellBehaviorOccupiable {

}
