﻿public class CellBehaviorTruckEntrance : CellBehavior {

    public override string getTooltipText() {
        return "Truck Entrance";
    }
}