﻿public class CellBehaviorTruckExit : CellBehavior {

    public bool isEntrance;

    public override string getTooltipText() {
        return "Truck Exit";
    }
}