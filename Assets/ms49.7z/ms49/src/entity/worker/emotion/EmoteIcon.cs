﻿using UnityEngine;
using System;

[Serializable]
public class EmoteIcon {

    public string emoteName;
    public Sprite icon;
}
