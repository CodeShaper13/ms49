﻿public enum EnumGender {
    UNDEFINED = 0,
    MALE = 1,
    FEMALE = 2,
    UNKNOWN = 3
}