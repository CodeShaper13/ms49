﻿using UnityEngine;
using System.Collections;

public enum EnumPayModifier {

    LOW = -1,
    NORMAL = 0,
    HIGH = 1,
}
