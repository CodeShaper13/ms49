﻿using System;

[Serializable]
public class GeneratedStructure {

    public Position pos;
    public StructureBase structure;
}
