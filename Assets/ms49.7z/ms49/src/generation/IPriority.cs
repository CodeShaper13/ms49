﻿public interface IPriority {

    int Priority { get; }
}