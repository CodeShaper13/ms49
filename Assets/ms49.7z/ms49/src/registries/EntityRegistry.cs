﻿using UnityEngine;

[CreateAssetMenu(fileName = "Registry", menuName = "MS49/Registry/Entity", order = 1)]
public class EntityRegistry : Registry<GameObject> { }