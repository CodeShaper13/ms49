﻿using System.Collections;
using UnityEngine;

[CreateAssetMenu(fileName = "Registry", menuName = "MS49/Registry/Item", order = 1)]
public class ItemRegistry : Registry<Item> {

}