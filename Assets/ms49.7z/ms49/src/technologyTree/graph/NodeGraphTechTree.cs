﻿using UnityEngine;
using XNode;

[CreateAssetMenu]
public class NodeGraphTechTree : NodeGraph { 
	
	// Don't delete, this IS used.
}