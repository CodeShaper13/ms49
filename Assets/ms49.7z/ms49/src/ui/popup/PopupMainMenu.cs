﻿using UnityEngine;
using System.Collections;

public class PopupMainMenu : PopupWindow {

}
