﻿using UnityEngine;

public class PopupTemperature : PopupWorldReference {

}
