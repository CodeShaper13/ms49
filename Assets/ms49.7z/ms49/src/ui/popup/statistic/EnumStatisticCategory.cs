﻿public enum EnumStatisticCategory {

    GENERAL = 0,
    TILES = 1,
    WORKERS = 2,
}
