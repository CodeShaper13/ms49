﻿public enum EnumAxis {
    X = 0,
    Y = 1,
}
