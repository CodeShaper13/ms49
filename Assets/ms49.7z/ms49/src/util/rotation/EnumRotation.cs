﻿public enum EnumRotation {

    UP = 0,
    RIGHT = 1,
    LEFT = 2,
    DOWN = 3,
    NONE = 4,
}