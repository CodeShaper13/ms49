﻿using UnityEngine;

[CreateAssetMenu(fileName = "Audio", menuName = "Variable/Audio", order = 1)]
public class AudioVariable : GenericVariable<AudioClip> {
}