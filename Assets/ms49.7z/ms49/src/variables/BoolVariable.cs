﻿using UnityEngine;

[CreateAssetMenu(fileName = "Boolean", menuName = "Variable/Boolean", order = 1)]
public class BoolVariable : GenericVariable<bool> {
}
