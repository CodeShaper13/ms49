﻿using UnityEngine;

[CreateAssetMenu(fileName = "Float", menuName = "Variable/Float", order = 1)]
public class FloatVariable : GenericVariable<float> { }