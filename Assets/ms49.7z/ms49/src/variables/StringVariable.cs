﻿using UnityEngine;

[CreateAssetMenu(fileName = "String", menuName = "Variable/String", order = 1)]
public class StringVariable : GenericVariable<string> {
}
