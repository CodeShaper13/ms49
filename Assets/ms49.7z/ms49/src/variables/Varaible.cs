﻿using UnityEngine;

public class Varaible : ScriptableObject { }