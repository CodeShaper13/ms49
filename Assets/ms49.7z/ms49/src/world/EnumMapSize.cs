﻿public enum EnumMapSize {
    SMALL = 0,
    MEDIUM = 1,
    LARGE = 2,
}
